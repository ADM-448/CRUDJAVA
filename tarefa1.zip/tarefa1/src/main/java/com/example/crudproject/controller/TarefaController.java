package com.example.crudproject.controller;

import com.example.crudproject.model.Tarefa;
import com.example.crudproject.model.Tarefa;
import com.example.crudproject.service.TarefaService;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@RestController
@RequestMapping("/tarefa")
public class TarefaController {

    @Autowired
    private TarefaService tarefaService;

    @GetMapping
    public List<Tarefa> getAllProducts() {
        return tarefaService.findAll();
    }

    @PostMapping
    public Tarefa createProduct(@RequestBody Tarefa tarefa) {
        return tarefaService.save(tarefa);
    }

    //Colocar para iniciar
    @PostMapping("/{id}/iniciar")
    public Tarefa iniciar(@PathVariable Long id){ //Mapeamento da Rota
        Tarefa tarefa = tarefaService.findById(id);//Localizar a Tarefa pelo ID
        tarefa.setStatus("Iniciar");//Definir a Nova Fase da Tarefa
        return tarefaService.save(tarefa);//Salvar as Alterações
    }/*@PathVariable Long id: Indica que este método responderá a requisições HTTP POST para a URL*/

    //Colocar para Andamento
    @PostMapping("/{id}/Andamento")
    public Tarefa Andamento(@PathVariable Long id){ //Mapeamento da Rota
        Tarefa tarefa = tarefaService.findById(id);//Localizar a Tarefa pelo ID
        tarefa.setStatus("Andamento");//Definir a Nova Fase da Tarefa
        return tarefaService.save(tarefa);//Salvar as Alterações
    }

    //Colocar para Finalizado
    @PostMapping("/{id}/Finalizado")
    public Tarefa Finalizado(@PathVariable Long id){ //Mapeamento da Rota
        Tarefa tarefa = tarefaService.findById(id);//Localizar a Tarefa pelo ID
        tarefa.setStatus("Finalizado");//Definir a Nova Fase da Tarefa
        return tarefaService.save(tarefa);//Salvar as Alterações
    }

}
