package com.example.crudproject.service;

import com.example.crudproject.model.Tarefa;
import com.example.crudproject.repository.TarefaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TarefaService {

    @Autowired
    private TarefaRepository productRepository;

    public List<Tarefa> findAll() {
        return productRepository.findAll();
    }

    public Tarefa findById(Long id) {
        return productRepository.findById(id).orElse(null);
    }

    public Tarefa save(Tarefa tarefa) {
        return productRepository.save(tarefa);
    }

    public void deleteById(Long id) {
        productRepository.deleteById(id);
    }
}
