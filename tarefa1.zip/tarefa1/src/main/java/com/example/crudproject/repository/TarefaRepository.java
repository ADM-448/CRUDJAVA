package com.example.crudproject.repository;

import com.example.crudproject.model.Tarefa;
import com.example.crudproject.model.Tarefa;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TarefaRepository extends JpaRepository<Tarefa, Long> {
}
