package com.example.crudproject.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Solicitacao {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private long id;

    private String nome;
    private String status;
    private String descricao;
    private String prioridade;
    private String dateAbertura;

    public Solicitacao() {}

    public Solicitacao(long id, String nome, String status, String descricao, String prioridade, String dateAbertura) {
        this.id = id;
        this.nome = nome;
        this.status = status;
        this.descricao = descricao;
        this.prioridade = prioridade;
        this.dateAbertura = dateAbertura;
    }

    public long getId() {
        return id;
    }

    public String getNome() {
        return nome;
    }

    public String getStatus() {
        return status;
    }

    public String getDescricao() {
        return descricao;
    }

    public String getPrioridade() {
        return prioridade;
    }

    public String getDateAbertura() {
        return dateAbertura;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Tarefa{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", status=" + status +
                ", prioridade=" + prioridade +
                ", data Abertura=" + dateAbertura +
                ", descrição=" + descricao +
                '}';
    }
}
