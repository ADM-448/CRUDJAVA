package com.example.crudproject.controller;

import com.example.crudproject.model.Solicitacao;
import com.example.crudproject.service.SolicitacaoService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/solicitacao")
public class SolicitacaoController {

    @Autowired
    private SolicitacaoService solicitacaoService;

    @GetMapping
    public List<Solicitacao> getAllTasks() {
        return solicitacaoService.findAll();
    }

    @PostMapping
    public Solicitacao createTask(@RequestBody Solicitacao solicitacao) {
        return solicitacaoService.save(solicitacao);
    }

    @PutMapping
    public Solicitacao editTask(@RequestBody Solicitacao solicitacao) {
        return solicitacaoService.save(solicitacao);
    }

    @PostMapping("/{id}/aberto")
    public Solicitacao iniciar(@PathVariable Long id) {
        Solicitacao solicitacao = solicitacaoService.findById(id);
        solicitacao.setStatus("ABERTO");
        return solicitacaoService.save(solicitacao);
    }

    @PutMapping("/{id}/avancarStatus")
    public Solicitacao avancarStatus(@PathVariable Long id) {
        Solicitacao solicitacao = solicitacaoService.findById(id);
        if (solicitacao == null) {
            throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Solicitacao não encontrada");
        }

        switch (solicitacao.getStatus()) {
            case "ABERTO":
                solicitacao.setStatus("ANDAMENTO");
                break;
            case "ANDAMENTO":
                solicitacao.setStatus("CONCLUIDO");
                break;
            default:
                return solicitacao;  // Se o status não for "ABERTO" ou "ANDAMENTO", retorna a SOLICITACAO sem alteração
        }
        return solicitacaoService.save(solicitacao);  // Salvando e retornando a SOLICITACAO atualizada
    }

    @DeleteMapping("/{id}")
    public void deleteTask(@PathVariable Long id) {
        solicitacaoService.deleteById(id);
    }


}
