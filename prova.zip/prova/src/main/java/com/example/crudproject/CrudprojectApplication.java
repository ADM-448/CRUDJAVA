package com.example.crudproject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudprojectApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudprojectApplication.class, args);
	}

}
/*
{
    "nome": "Solicitacao Exemplo",
    "status": "ABERTO",
    "prioridade": "alta",
    "dateAbertura": "12/11 - 10:00",
    "descricao": "descrição"
}



GET http://localhost:8080/solicitacao

POST http://localhost:8080/solicitacao

PUT http://localhost:8080/solicitacao/1/avancarStatus

DELETE http://localhost:8080/solicitacao/1



 */