package com.example.crudproject.service;
import com.example.crudproject.model.Solicitacao;
import com.example.crudproject.repository.SolicitacaoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SolicitacaoService {

    @Autowired
    private SolicitacaoRepository solicitacaoRepository;

    public List<Solicitacao> findAll() {
        return solicitacaoRepository.findAll();
    }

    public Solicitacao findById(Long id) {
        return solicitacaoRepository.findById(id).orElse(null);
    }

    public Solicitacao save(Solicitacao solicitacao) {
        return solicitacaoRepository.save(solicitacao);
    }

    public void deleteById(Long id) {
        solicitacaoRepository.deleteById(id);
    }
}
